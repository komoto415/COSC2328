<?php
  $name = $_POST["name"];
  $major = $_POST["major"];
  $school = $_POST["school"];
  echo "Dear ".$name." you have been accepted into ".$school." with a major of ".$major.".";
?>
