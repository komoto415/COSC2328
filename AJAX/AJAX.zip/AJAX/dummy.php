<?php
  echo "<h1>This is a simple sample text</h1>";
?>
