console.log(window.location.search);
alert(window.location.search)