<?php
	$name = $_POST["name"];
	$email = $_POST["email"];
	$pass = $_POST["pass"];
	echo "Excellent! ".$name." you are now registered at ".$email.". <b>Please do not lose your password!</b>";

?>